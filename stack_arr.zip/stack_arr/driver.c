#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>

#include "stack_arr.h"


int checkEqu(char equ[], Stack312 *s);
bool compareChar(char com, char to);
void outResult(Stack312 *s);
char getOppsite(StackEntry in);

int main(int argc, char * argv[]){
	
	FILE *in = fopen(argv[1], "r");
	if(in == NULL){
		printf("File not Found\n");
		exit(1);
	}
	else {
		printf("\n");
	}
	Stack312 *stack = NULL;
	stack = (Stack312 *) malloc(sizeof(Stack312));
	makeStack(stack);
	
	char buffer[100];
	
	while(fgets(buffer, 100, in) != NULL){
		checkEqu(buffer, stack);
	}
	
	
	
	fclose(in);
}


int checkEqu(char equ[], Stack312 *s){
	
	int len = strlen(equ);
	if(equ[len-1] == 0x0A){
		len--;
	}	
	for(int i = 0; i < len; i++){
		printf("%c", equ[i]);
		char Char = equ[i];
		if(Char == '[' || Char == '{' || Char == '('){
			push(Char, s);
		}
		else if(Char == ']' || Char == '}' || Char == ')'){
			char popped = pop(s);
			if(!(compareChar(popped, Char))){
				push(popped, s);
				push(Char,s);
			}
		}
	}
	
	outResult(s);
	
	return 0;
}

bool compareChar(char com, char to){
	if(com == '[' && to == ']'){
		return true;
	}
	else if(com == '{' && to == '}'){
		return true;
	}
	else if(com == '(' && to == ')'){
		return true;
	}
}

void outResult(Stack312 *s){
	printf(" === ");
	char out = 0;
	if(isEmpty(*s)){
		printf(" Valid Expression\n\n");
	}
	else{
		printf(" Missing ");
		while(!isEmpty(*s)){
			printf("%c", getOppsite(pop(s)));
		}
		printf("\n\n");
	}
}

char getOppsite(StackEntry in){
	if(in == '('){
		return ')';
	}
	else if(in == '{'){
		return '}';
	}
	else if(in == '['){
		return ']';
	}
	else if(in == ')'){
		return '(';
	}
	else if(in == '}'){
		return '{';
	}
	else if(in == ']'){
		return '[';
	}
}



