//implementation
#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#include "stack_arr.h"

void makeStack(Stack312 *s){
	if(s != NULL){
		free(s);
	}
	s = (Stack312 *) malloc(sizeof(Stack312));
}

bool isFull(Stack312 s){
	if(s.top == 100){
		return true;
	}
	else return false;
}
bool isEmpty(Stack312 s){
	if(s.top == 0){
		return true;
	}
	else return false;
}

void push(StackEntry e,Stack312 *s){
	if(!isFull(*s)){
		s->elements[s->top] = e;
		(s->top)++;
	}
}

StackEntry pop(Stack312 *s){
	if(!isEmpty(*s)){
		(s->top)--;
		return s->elements[s->top];
	}
}
