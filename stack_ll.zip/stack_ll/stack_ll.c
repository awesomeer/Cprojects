#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>

#include "stack_ll.h"


void makeStack(Stack312 *s){
	s->top = NULL;
}

bool isFull(Stack312 s){
	return false;
}

bool isEmpty(Stack312 s){
	if(s.top == NULL){
		return true;
	}
	else{
		return false;
	}
}

void push(StackEntry e,Stack312 *s){
	StackNode *temp = malloc(sizeof(StackNode));
	temp->pixel = e;
	temp->next = s->top;
	s->top = temp;
}

StackEntry pop(Stack312 *s){
	if(!isEmpty(*s)){
		StackNode *ret = s->top;
		s->top = s->top->next;
		StackEntry pixel = ret->pixel;
		free(ret);
		return pixel;
	}
}
