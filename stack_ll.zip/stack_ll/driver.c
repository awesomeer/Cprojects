#include <stdio.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "stack_ll.h"

void readPic(FILE *in, char *pic[], int *row, int *col);
void floodFill(char *pic[], int numRow, int numCol, int x, int y, char c, Stack312 *s);
void printPic(char *pic[], int numRows);

int main(int argc, char *argv[]){
	
	int x = 0, y =0, numRow = 0, numCol = 0;
	char color = 0;
	
	FILE *in = fopen(argv[1], "r");
	if(in == NULL){
		printf("File not found\n");
		exit(1);
	}
	
	char *pic[25];
	
	readPic(in, pic, &numRow, &numCol);
	
	printPic(pic, numRow);
	
	
	Stack312 *stack = (Stack312 *) malloc(sizeof(Stack312));
	makeStack(stack);
	
	while(1){
		do{
			printf("Enter a Row: ");
			scanf("%d", &y);
			
			printf("Enter a Column: ");
			scanf("%d", &x);
			
			printf("Enter a Color: ");
			scanf("%c", &color);
			scanf("%c", &color);
			
			if(y >= numRow || x >= numCol){
				printf("\nRow or Column out of bounds\n\n");
			}
			else {
				break;
			}
			
		}while(1);
		
		if(y < 0 || x < 0){
			break;
		}
		
		if(color != pic[y][x]){
			floodFill(pic, numRow, numCol, x, y, color, stack);
		}
		printPic(pic, numRow);
	}
	
	
	fclose(in);
	free(stack);
	for(int i = 0; i < numRow; i++){
		free(pic[i]);
	}
}

void readPic(FILE *in, char *pic[], int *row, int *col){
	char buff[100];
	while(fgets(buff, 100, in) != NULL){
		pic[*row] = (char *) malloc(strlen(buff) + 1);
		strcpy(pic[*row], buff);
		(*row)++;
	}
	
	*col = strlen(buff) - 1;
}

void floodFill(char *pic[], int numRows, int numCols, int x, int y, char color, Stack312 *stack){
	char compare = pic[y][x];
	Pixel start = {y,x,compare};
	
	push(start, stack);
	while(!isEmpty(*stack)){
		
		Pixel popped = pop(stack);
		int row = popped.row;
		int col = popped.col;
		
		if(pic[row][col] == compare){
			pic[row][col] = color;
			
			row--;
			col--;
			
			for(int r = 0; r < 3; r++){
				if( row+r > -1 && row+r < numRows){
					for(int c = 0; c < 3; c++){
						if( col+c > -1 && col+c < numCols){
							Pixel pushPix = {row+r, col+c, pic[row+r][col+c]};
							push(pushPix, stack);
						}
					}
				}
			}
		}
	}
}

void printPic(char *pic[], int numRows){
	printf("\n");
	for(int i = 0; i < numRows; i++){
		printf("%s", pic[i]);
	}
	printf("\n");
}







































